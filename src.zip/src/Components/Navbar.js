// import React from 'react';
// import { Container } from 'react-bootstrap';



  
// const Navbar = () => {
//   return (
//     <>
     
//     <Container>
//       <Navbar.Brand href="#home">Hr Clone</Navbar.Brand>
//     </Container>
  
//   <br />
//     </>
//   );
// };
  
// export default Navbar;