import React, {useState, useEffect} from "react";
import 'bootstrap/dist/css/bootstrap.min.css';
import { Button, Col, FloatingLabel, Form, Row } from "react-bootstrap";
<link
  rel="stylesheet"
  href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css"
  integrity="sha384-1BmE4kWBq78iYhFldvKuhfTAU6auU8tT94WrHftjDbrCEXSU1oBoqyl2QvZ6jIW3"
  crossorigin="anonymous"
/>




const Home = () => {
    const [type,setType] = useState({id:0,emp_code:"",name:"",department:"",gender:"",dob:"",joining_date:"",prev_experience:"",salary:"",address:""});
    const [arrays, setArrays]= useState([]);

    function updateName(event) {
      setType({...type,name:event.target.value});
      console.log(type);
    }

    function updateEmpCode(event) {
      setType({...type,emp_code:event.target.value});
      console.log(type);
    }

    function updateDepartment(event) {
      setType({...type,department:event.target.value});
      console.log(type);
    }

    function updateGender(event) {
      setType({...type,gender:event.target.value});
      console.log(type);
    }

    function updateDob(event) {
      setType({...type,dob:event.target.value});
      console.log(type);
    }

    function updateJoiningDate(event) {
      setType({...type,joining_date:event.target.value});
      console.log(type);
    }

    function updatePrevExperience(event) {
      setType({...type,prev_experience:event.target.value});
      console.log(type);
    }
    function updateSalary(event) {
      setType({...type,salary:event.target.value});
      console.log(type);
    }
    function updateAddress(event) {
      setType({...type,address:event.target.value});
      console.log(type);
    }

    useEffect(()=>{
        fetch(`http://localhost/hrclone/json_data.php`)
        .then(response => response.json())
        .then(json => setArrays(json))
    },[type]);
    console.log(arrays);



    return (
      <div className="container">
          <br />
        {/* <form>
        <input type="hidden" name="id" />
       <div>
          <label >Emp Cpde</label>
          <input onChange={updateEmpCode} type="text" id="emp_code" name="emp_code" value={type.emp_code} placeholder="Enter emp code"/>
        </div>
       
     
      <div >
        <div >
          <label >Name</label>
          <input onChange={updateName} type="text"  id="name" name="name" value={type.name} placeholder="Enter name"/>
        </div>
       
      </div>
      <div className="form-row">
        <div >
          <label  >Department</label>
          <select onChange={updateDepartment} aria-label="" name="department" id="department" >
            <option disabled value="">Select Department</option>
            <option value="Admin">Admin</option>
            <option value="Technology">Technology</option>
            <option value="Accounts">Accounts</option>
          </select>
        </div>
       
      </div>
      <div>
        <label>Gender</label>
        <div >
      <input type="radio"  id="male" name="gender" value="Male" />
      <label >Male</label>
    </div>
    <div >
      <input type="radio"  id="female" name="gender" value="Female"/>
      <label >Female</label>
    </div>
    <div >
      <input type="radio"  id="other" name="gender" value="Other" />
      <label>Other</label>
    </div>
      </div>
    
      <div>
        <label >DOB</label>
        <input onChange={updateDob} type="date" id="dob" name="dob" placeholder="Enter DOB"/>
      </div>
    
       <div >
        <label>Joining Date</label>
        <input onChange={updateJoiningDate} type="date"  id="joining_date" name="joining_date" placeholder="Enter joining date"/>
      </div>
    
       <div >
        <div >
          <label >Prev Experience</label>
          <input onChange={updatePrevExperience} type="text" className="form-control" id="prev_experience" name="prev_experience" placeholder="Enter prev exp."/>
        </div>
       
      </div>
      <div >
        <div >
          <label >Salary</label>
          <input onChange={updateSalary} type="number"  id="salary" name="salary" placeholder="Enter salary" />
        </div>
       
      </div>
    
      <div className="form-row">
        <div>
          <label>Address</label>
          <textarea onChange={updateAddress}  name="address" maxLength="150" rows="3"></textarea>
        </div>
        </div>
        <br/>
      <button type="submit" >Submit </button>
    </form>
 */}




    <Form>
  <Form.Group as={Row} className="mb-3" controlId="formHorizontalEmail">
    <Form.Label column sm={1}>
       Emp Code
    </Form.Label>
    <Col sm={10}>
      <Form.Control type="text" placeholder="Enter your Employee Code" />
    </Col>
  </Form.Group>

  <Form.Group as={Row} className="mb-3">
    <Form.Label column sm={1}>
      Name
    </Form.Label>
    <Col sm={10}>
      <Form.Control type="text" placeholder="Enter your Name" />
    </Col>
  </Form.Group>


  <Form.Group as={Col}  controlId="formGridState">
      <Form.Label>State</Form.Label>
      <Form.Select className="mb-3" defaultValue="Choose...">
        <option>Admin</option>
        <option>Technology</option>
        <option>Accounts</option>
      </Form.Select>
    </Form.Group>

  <fieldset>
    <Form.Group as={Row} className="mb-3">
      <Form.Label as="legend" column sm={1}>
        Gender
      </Form.Label>
      <Col sm={10}>
        <Form.Check
          type="radio"
          label="Male"
          name="formHorizontalRadios"
          id="formHorizontalRadios1"
        />
        <Form.Check
          type="radio"
          label="Female"
          name="formHorizontalRadios"
          id="formHorizontalRadios2"
        />
        <Form.Check
          type="radio"
          label="Other"
          name="formHorizontalRadios"
          id="formHorizontalRadios3"
        />
      </Col>
    </Form.Group>
  </fieldset>

  <Form.Group as={Row} className="mb-3" controlId="formHorizontalEmail">
    <Form.Label column sm={1}>
      Dob
    </Form.Label>
    <Col sm={10}>
      <Form.Control type="date" placeholder="Enter your Employee Code" />
    </Col>
  </Form.Group>

  <Form.Group as={Row} className="mb-3" controlId="formHorizontalEmail">
    <Form.Label column sm={1}>
      Joining-Date
    </Form.Label>
    <Col sm={10}>
      <Form.Control type="date" placeholder="Enter your Employee Code" />
    </Col>
  </Form.Group>

  <Form.Group as={Row} className="mb-3">
    <Form.Label column sm={1} sm={1}>
     Prev-Experience
    </Form.Label>
    <Col sm={10}>
      <Form.Control type="text" placeholder="Enter your Previous Experience" />
    </Col>
  </Form.Group>

  <Form.Group as={Row} className="mb-3">
    <Form.Label column sm={1}>
      Salary
    </Form.Label>
    <Col sm={10}>
      <Form.Control type="text" placeholder="Enter Salary" />
    </Col>
  </Form.Group>

  <Form.Label column sm={1}>
      Address
    </Form.Label>
  <FloatingLabel controlId="floatingTextarea2" >
    <Form.Control
      as="textarea"
      placeholder="Leave a address here"
      style={{ height: '100px' },{ width:'650px'},{ paddingLeft:'100px'}}
    />
  </FloatingLabel>
  <br />

  
  

  <Form.Group as={Row} className="mb-6">
    <Col sm={{ span: 10, offset: 5}}>
      <Button type="submit">Submit</Button>
    </Col>
  </Form.Group>
</Form>

<br />

      <table className="table">
        <thead>
          <tr>
            <th>Emp Code</th>
            <th>Name</th>
            <th>Department</th>
            <th>Gender</th>
            <th>DOB</th>
            <th>Joining Date</th>
            <th>Prev Experience</th>
            <th>Salary</th>
            <th>Address</th>
            <th>Action</th>
          </tr>
        </thead>

        <tbody>
        {
            arrays.map(array =>{
              return(
              <tr>
                {/* {setType(array)} */}
                <td>{array.emp_code}</td>
                <td>{array.name}</td>
                <td>{array.department}</td>
                <td>{array.gender}</td>
                <td>{array.dob}</td>
                <td>{array.joining_date}</td>
                <td>{array.prev_experience}</td>
                <td>{array.salary}</td>
                <td>{array.address}</td>
                <button id={array.id} onClick={()=>{setType(array)}}>Edit</button>
              </tr>)
            })
        }
        </tbody>
       
      </table>
      </div>
    
    );
  };
    
  export default Home;